
    
package com.dineshonjava.def;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/ResetPassword1")
public class ResetPassword1 extends HttpServlet {
    PreparedStatement st = null;
    Connection con = null;
    ResultSet rs = null;


    public void init() {
        System.out.println("init");
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "123456789");


        } catch (Exception ae) {
            System.out.println("Sorry! Database is not connected");
        }
    }


    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();


        String a = req.getParameter("t1");
        String b = req.getParameter("t2");
        HttpSession ses = req.getSession(false);// New Session is created
        
        String a1=(String)ses.getAttribute("x"); 
        String b1=(String)ses.getAttribute("y"); 
        String c1=(String)ses.getAttribute("z");
        
        try {


            if (a.equals(b)) {
                st = con.prepareStatement("update users set password=? where email=?");
                st.setString(1, a);
                st.setString(2, b1);
                st.executeQuery();
                
                res.sendRedirect("index.jsp");
            } else {
                res.sendRedirect("changepassword.jsp");
            }


        } catch (Exception at) {
            out.println("Sorry! unable to retrieve record");


        }
        out.println("</body>");
        out.println("</html>");
    }


}













